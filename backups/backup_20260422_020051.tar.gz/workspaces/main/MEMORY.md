

## Dev Server 50.34 — ai-api Pipeline DB Credentials

Credentials moved to `.env` — see `MYSQL_READ_HOST`, `MYSQL_WRITE_HOST`, `LOCAL_PG_URL`, `SUPABASE_PG_URL`, `AUDIT_DB_URL` in `~/JjayFiles/claude-command-center/.env`.

## Development Environment

- Primary dev server: **devbox** — 192.168.50.34 (SSH alias: `devbox`, user: `dev-user`)
- Projects run on devbox, NOT on local PC. Always SSH to devbox when running, testing, or inspecting project files.
- Known projects on devbox:
  - `~/ai-api` — FastAPI backend (Python, uvicorn on port 8000)
  - `~/datahub-pro` — Vue 3 frontend (Vite)
- When writing project charters, "How to Run" section should reference devbox commands, not local commands.
- Project charters planned: one per project, to be drafted in a future session.
- Charter template finalized: covers §0 Bootstrap, §1 Identity, §2 Repo Shape, §3 Living References, §4 Tech Stack, §5 Architecture, §6 Conventions, §7 Hard Rules, §8 Tech Debt, §9 Service Detail, §10 Current Focus, §11 Claude Working Style, §11.5 Commit/PR Conventions, §12 Open Questions.

## Project Charter Convention

- Each project gets a `CHARTER.md` saved in the repo root on the relevant server
- `~/MEMORY.md` stores a registry: project name, server, repo path, charter path
- At the start of any project work session, read the charter first before doing anything
- Charter template finalized (§0–§12 including §11.5 Commit/PR Conventions)
- Server per project must be confirmed by the user — do not assume devbox for all projects
- "How to Run" section: SSH into the server and inspect actual running processes (pm2, uvicorn, ports) — do not assume
- Vercel deployment decision pending — update charter deployment section when decided

## Project Registry

| Project | Server | Repo Path | Charter |
|---|---|---|---|
| datahub-pro | devbox (192.168.50.34) | ~/datahub-pro | ~/datahub-pro/CHARTER.md |
| ai-api | devbox (192.168.50.34) | ~/ai-api | ~/ai-api/CHARTER.md (not yet written) |

## Project Registry

| Project | Server | Repo Path | Charter |
|---|---|---|---|
| datahub-pro | devbox (192.168.50.34) | ~/datahub-pro | ~/JjayFiles/claude-command-center/charters/datahub-pro.md |
| ai-api | devbox (192.168.50.34) | ~/ai-api | ~/JjayFiles/claude-command-center/charters/ai-api.md (not yet written) |

## Project Registry (updated — replaces previous entries)

| Project | Server | Repo Path | Charter |
|---|---|---|---|
| datahub-pro | devbox (192.168.50.34) | ~/datahub-pro | ~/JjayFiles/claude-command-center/charters/datahub-pro.md |

Note: datahub-pro charter (§9) covers all relevant ai-api endpoints. No separate ai-api charter needed unless working on ai-api internals independently.

## datahub-pro — Active Initiative

**ICP Chatbot** — floating multi-turn chatbot on DataCount page
- Spec: `~/datahub-pro/docs/superpowers/specs/2026-04-21-icp-chatbot-design.md` (commit fb6d15d)
- Status: Design approved, implementation plan not yet written
- Next step: invoke writing-plans skill, then implement
- Key decisions locked:
  - Hybrid approach: frontend owns UI/localStorage, backend owns AI call + system prompt
  - New endpoint: POST /api/datahub/icp-chat
  - New files: IcpChatbot.vue + useIcpChat.js
  - Strictly scoped to ICP filter collection only — no off-topic responses
  - Confirmation required before populating DataCount fields
  - localStorage persistence (Option A), "New Chat" to reset
  - DataCount page opens to all users (remove from ADMIN_ONLY)
  - AI model: TBD (Gemini or OpenAI)
