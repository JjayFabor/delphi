

## Dev Server 50.34 — ai-api Pipeline DB Credentials

Credentials moved to `.env` — see `MYSQL_READ_HOST`, `MYSQL_WRITE_HOST`, `LOCAL_PG_URL`, `SUPABASE_PG_URL`, `AUDIT_DB_URL` in `~/JjayFiles/claude-command-center/.env`.

## Development Environment

- Primary dev server: **devbox** — 192.168.50.34 (SSH alias: `devbox`, user: `dev-user`)
- Projects run on devbox, NOT on local PC. Always SSH to devbox when running, testing, or inspecting project files.
- Known projects on devbox:
  - `~/ai-api` — FastAPI backend (Python, uvicorn on port 8000)
  - `~/datahub-pro` — Vue 3 frontend (Vite)
- When writing project charters, "How to Run" section should reference devbox commands, not local commands.
- Project charters planned: one per project, to be drafted in a future session.
- Charter template finalized: covers §0 Bootstrap, §1 Identity, §2 Repo Shape, §3 Living References, §4 Tech Stack, §5 Architecture, §6 Conventions, §7 Hard Rules, §8 Tech Debt, §9 Service Detail, §10 Current Focus, §11 Claude Working Style, §11.5 Commit/PR Conventions, §12 Open Questions.

## Project Charter Convention

- Each project gets a `CHARTER.md` saved in the repo root on the relevant server
- `~/MEMORY.md` stores a registry: project name, server, repo path, charter path
- At the start of any project work session, read the charter first before doing anything
- Charter template finalized (§0–§12 including §11.5 Commit/PR Conventions)
- Server per project must be confirmed by the user — do not assume devbox for all projects
- "How to Run" section: SSH into the server and inspect actual running processes (pm2, uvicorn, ports) — do not assume
- Vercel deployment decision pending — update charter deployment section when decided

## Project Registry

| Project | Server | Repo Path | Charter |
|---|---|---|---|
| datahub-pro | devbox (192.168.50.34) | ~/datahub-pro | ~/datahub-pro/CHARTER.md |
| ai-api | devbox (192.168.50.34) | ~/ai-api | ~/ai-api/CHARTER.md (not yet written) |

## Project Registry

| Project | Server | Repo Path | Charter |
|---|---|---|---|
| datahub-pro | devbox (192.168.50.34) | ~/datahub-pro | ~/JjayFiles/claude-command-center/charters/datahub-pro.md |
| ai-api | devbox (192.168.50.34) | ~/ai-api | ~/JjayFiles/claude-command-center/charters/ai-api.md (not yet written) |

## Project Registry (updated — replaces previous entries)

| Project | Server | Repo Path | Charter |
|---|---|---|---|
| datahub-pro | devbox (192.168.50.34) | ~/datahub-pro | ~/JjayFiles/claude-command-center/charters/datahub-pro.md |

Note: datahub-pro charter (§9) covers all relevant ai-api endpoints. No separate ai-api charter needed unless working on ai-api internals independently.

## datahub-pro — Current State (updated 2026-04-23)

**ICP Chatbot** — ✅ SHIPPED
- Files: `src/components/ui/IcpChatbot.vue`, `src/composables/useIcpChat.js`
- Backend: `POST /api/datahub/icp-chat` (routers/icp_chat.py), `POST /api/datahub/icp-extract`
- Features: file/URL extraction → filter chips, multi-turn chat, localStorage persistence, inline new-chat confirm bar, extract_context passed as synthetic model turn
- DataCount + chatbot open to all users (not just admins)
- Nginx 413 fix applied (client_max_body_size 15M) — done 2026-04-23

**Pending backlog:**
- `requested_by_tg_id` on Apollo reports — `dhp_tgid` never stored in localStorage so non-admin users can't see their own Apollo reports in history. Fix: use `agent` field as fallback in history query.
- `src/components/ui/useIcpChat.js` — untracked in git, needs commit

## Code Editing Rule — devbox (192.168.50.34)

NEVER edit files locally at /home/jjay/ and scp to devbox.
ALL code changes must be made DIRECTLY on devbox via SSH.

- Use `ssh devbox` with Python/sed/heredoc to do in-place edits on the server
- Files live at /home/dev-user/ai-api/ and /home/dev-user/datahub-pro/
- Read files: `ssh devbox "cat ~/ai-api/path/to/file.py"`
- Edit files: `ssh devbox "python3 - <<'EOF' ... EOF"` or `ssh devbox "sed -i ..."` 
- Never use the local Edit/Write tools on /home/jjay/ project files, then scp
- User explicitly stated: always do code changes on 50.34, not locally

## Callbox Master Database Reference

A living query reference doc has been created at:
`~/JjayFiles/claude-command-center/charters/callbox-master-db.md`

Contains:
- All DB connection info (BigBox PG, DW2 MySQL, Supabase, Pipeline)
- Quick psql access commands
- All current table descriptions for callbox_bigbox
- Useful queries: report stats, cleanup, user lookup, cascade delete, ICP run IDs
- DW2 MySQL key tables and sample queries
- Notes on quirks (admin_divs leading whitespace, filters as JSONB, etc.)

When the user asks "how do I query X" or "how do I check the DB" — read this file first.
When new queries are discovered/used, append them to this file under the relevant section.
